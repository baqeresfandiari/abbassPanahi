/** Automatically generated file. DO NOT MODIFY */
package com.Taban.passport;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}